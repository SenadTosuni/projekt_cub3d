﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;

namespace Tetris_The_Game
{
      class Spielfeld
        {
            private int Zeile;
            private int Spalten;
            private int Punkte;
            private int VolleLinie;
            private Figuren grFigur;
            private Label[,] Block;

             private Brush TransBrush = Brushes.Transparent;
             private Brush RedBrush = Brushes.Red;
            
            // Der Grid wird übergeben        
            public Spielfeld(Grid TetrisG)
            {
                // Die Anzahl der Zeilen des Grids werden übergeben
                Zeile = TetrisG.RowDefinitions.Count;
                // Die Spalten des Grids werden übergeben
                Spalten = TetrisG.ColumnDefinitions.Count;

                Punkte = 0;
                VolleLinie = 0;
                
                
                Block = new Label[Spalten, Zeile];

                for (int i = 0; i < Spalten; i++)
                {
                    for (int e = 0; e < Zeile; e++)
                    {
                        // Es werden Blöcke erzeugt 
                        Block[i, e] = new Label();
                        // Die Farbe der Blöcke werden auf Transparent gesetzt
                        Block[i, e].Background = TransBrush;
                        // Der Rand ist Rot
                        Block[i, e].BorderBrush = RedBrush;
                        // Der Rand ist auf jeder Seite rot
                        Block[i, e].BorderThickness = new Thickness(0.5, 0.5, 0.5, 0.5);
                        
                        Grid.SetRow(Block[i, e], e);
                        Grid.SetColumn(Block[i, e], i);
                        TetrisG.Children.Add(Block[i, e]);
                    }
                }
                grFigur = new Figuren();
                Figuren_zeichnen();
            }


            public int get_punkte()
            {
                return Punkte;
            }

            public int get_lines()
            {
                return VolleLinie;
            }
            
            
            private void Figuren_zeichnen()
            {
                // Wo malen:
                Point Position = grFigur.get_Position();
                // Was malen:
                Point[] Shape = grFigur.get_Figur();
                Brush Farbe = grFigur.get_Farbe();

                foreach (Point s in Shape)
                {
                    Block[(int)(s.X + Position.X) + ((Spalten / 2) - 1),
                        (int)(s.Y + Position.Y) + 2].Background = Farbe;
                }
            }
            private void Figuren_loeschen()
            {
                // Wo malen:
                Point Position = grFigur.get_Position();
                // Was malen:
                Point[] Shape = grFigur.get_Figur();

                foreach (Point s in Shape)
                {
                    Block[(int)(s.X + Position.X) + ((Spalten / 2) - 1),
                        (int)(s.Y + Position.Y) + 2].Background = TransBrush;
                }
            }
            // Prüft ob die Zeilen voll sind. 
            private void prf_Zeilen()
            {
                bool voll;
                for (int i = Zeile - 1; i > 0; i--)
                {
                    voll = true;
                    for (int e = 0; e < Spalten; e++)
                    {
                        
                        if (Block[e, i].Background == TransBrush)
                        {
                            voll = false;

                        }
                    }
                    //Wenn es voll ist bekommt man 100 Punkte. Die werden dann per Label ausgegeben. 
                    if (voll)
                    {
                        RemoveRow(i);
                        Punkte += 100;
                       
                    }
                }
            }
            private void RemoveRow(int r)
            {
                for (int i = r; i > 2; i--)
                {
                    for (int e = 0; e < Spalten; e++)
                    {
                        Block[e, i].Background = Block[e, i - 1].Background;
                    }
                }
            }
            public void FigurLinks()
            {
                Point Position = grFigur.get_Position();
                Point[] Figur = grFigur.get_Figur();
                bool move = true;
                Figuren_loeschen();
                foreach (Point f in Figur)
                {
                    if (((int)(f.X + Position.X) + ((Spalten / 2) - 1) - 1) < 0)
                    {
                        move = false;
                    }
                    else if (Block[((int)(f.X + Position.X) + ((Spalten / 2) - 1) - 1),
                                (int)(f.Y + Position.Y) + 2].Background != TransBrush)
                    {
                        move = false;
                    }

                }
                if (move)
                {
                    grFigur.nachLinks();
                    Figuren_zeichnen();
                }
                else
                {
                    Figuren_zeichnen();
                }
            }
            public void FigurRechts()
            {
                Point Position = grFigur.get_Position();
                Point[] Figur = grFigur.get_Figur();
                bool move = true;
                Figuren_loeschen();

                foreach (Point f in Figur)
                {
                    if (((int)(f.X + Position.X) + ((Spalten / 2) - 1) + 1) >= Spalten)
                    {
                        move = false;
                    }
                    else if (Block[((int)(f.X + Position.X) + ((Spalten / 2) - 1) + 1),
                                (int)(f.Y + Position.Y) + 2].Background != TransBrush)
                    {
                        move = false;
                    }

                }
                if (move)
                {
                    grFigur.nachRechts();
                    Figuren_zeichnen();
                }
                else
                {
                    Figuren_zeichnen();
                }


            }
            public void FigurUnten()
            {
                Point Position = grFigur.get_Position();
                Point[] Figur = grFigur.get_Figur();
                bool move = true;
                Figuren_loeschen();
                foreach (Point f in Figur)
                {
                    if (((int)(f.Y + Position.Y) + 2 + 1) >= Zeile)
                    {
                        move = false;
                    }
                    else if (Block[((int)(f.X + Position.X) + ((Spalten / 2) - 1)),
                                (int)(f.Y + Position.Y) + 2 + 1].Background != TransBrush)
                    {
                        move = false;
                    }

                }
                if (move)
                {
                    grFigur.nachUnten();
                    Figuren_zeichnen();
                }
                else
                {
                    Figuren_zeichnen();
                    prf_Zeilen();
                    grFigur = new Figuren();
                }

            }
            public void Rotation()
            {
                Point Position = grFigur.get_Position();
                Point[] S = new Point[4];
                Point[] Figur = grFigur.get_Figur();
                bool move = true;

                Figur.CopyTo(S, 0);
                Figuren_loeschen();
                for (int i = 0; i < S.Length; i++)
                {
                    double x = S[i].X;
                    S[i].X = S[i].Y * -1;
                    S[i].Y = x;

                    if (((int)((S[i].Y + Position.Y) + 2)) >= Zeile)
                    {
                        move = false;
                    }
                    else if (((int)(S[i].X + Position.X) + ((Spalten / 2) - 1)) < 0)
                    {
                        move = false;
                    }
                    else if (((int)(S[i].X + Position.X) + ((Spalten / 2) - 1)) >= Zeile)
                    {
                        move = false;
                    }
                    else if (Block[((int)(S[i].X + Position.X) + ((Spalten / 2) - 1)),
                        (int)(S[i].Y + Position.Y) + 2].Background != TransBrush)
                    { move = false; }
                }
                if (move)
                {
                    grFigur.Rotieren();
                    Figuren_zeichnen();
                }
                else
                {
                    Figuren_zeichnen();
                }
                
        }
                
            
        }
}
