﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Tetris_The_Game
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer Timer;
        Spielfeld feld;

        
        public MainWindow()
        {
            InitializeComponent();
        }
        void MainWindow_Initialize(object sender, EventArgs e)
        {
            Spielfeld punkte = new Spielfeld(g_tetris);
            int g = punkte.get_punkte();


           
            
            Timer = new DispatcherTimer();
            Timer.Tick += new EventHandler(Punktezähler);
            Timer.Interval = new TimeSpan(0, 0,1);
            GameStart();

        }
        
        //Löscht alles und startet das Spiel neu.
        private void GameStart()
        {
            g_tetris.Children.Clear();
            feld = new Spielfeld(g_tetris);
            Timer.Start();
        }
       
        void Punktezähler(object sender, EventArgs e)
        {   // Zählt die Punkte

              l_punkte.Content = feld.get_punkte().ToString("000000000");
          
            feld.FigurUnten();
        }
        private void HandleKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Left:
                    if (Timer.IsEnabled) feld.FigurLinks();
                    break;
                case Key.Right:
                    if (Timer.IsEnabled) feld.FigurRechts();
                    break;
                case Key.Down:
                    if (Timer.IsEnabled) feld.FigurUnten();
                    break;
               case Key.Up:
                    if (Timer.IsEnabled) feld.Rotation();
                    break;
                case Key.Enter:
                    GameStart();
                    break;
                default:
                    break;
            }
        }

        private void b_start_Click(object sender, RoutedEventArgs e)
        {
                GameStart();

        }

    }
}
