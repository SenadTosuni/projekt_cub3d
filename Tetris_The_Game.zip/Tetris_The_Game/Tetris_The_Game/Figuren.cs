﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace Tetris_The_Game
{
    class Figuren
    {
        private Point currPosition;
        private Point[] Shape;
        private Brush Farbe;
        private bool rotieren;

        // 
        public Figuren()
        {
            currPosition = new Point(0, 0);
            Farbe = Brushes.Transparent;
            Shape = rShapes();

        }

        // Erstellt die Figuren und gibt sie zufällig aus.
        private Point[] rShapes()
        {
            Random r = new Random();
            switch (r.Next() % 7)
            {
                case 0: // I
                    rotieren = true;
                    Farbe = Brushes.Black;
                    return new Point[]
                    {new Point(0,0),
                     new Point(-1,0),
                     new Point(1,0),
                     new Point(2,0)};

                case 1: // J
                    rotieren = true;
                    Farbe = Brushes.White;
                    return new Point[]
                    {new Point(0,0),
                     new Point(-1,0),
                     new Point(1,0),
                     new Point(1,1)};

                case 2: //L
                    rotieren = true;
                    Farbe = Brushes.Black;
                    return new Point[]
                    {new Point(-1,0),
                     new Point(0,0),
                     new Point(1,0),
                     new Point(1,-1)};

                case 3: //Würfel
                    rotieren = false;
                    Farbe = Brushes.White;
                    return new Point[]
                    {new Point(0,0),
                     new Point(0,1),
                     new Point(1,0),
                     new Point(1,1)};

                case 4: //Verkehrtes Z
                    rotieren = true;
                    Farbe = Brushes.Black;
                    return new Point[]
                   {new Point(0,0),
                    new Point(-1,0),
                    new Point(0,1),
                    new Point(-1,-1)};

                case 5: //T
                    rotieren = true;
                    Farbe = Brushes.Black;
                    return new Point[]
                   {new Point(0,0),
                    new Point(-1,0),
                    new Point(0,-1),
                    new Point(1,0)};

                case 6: //Z
                    rotieren = true;
                    Farbe = Brushes.White;
                    return new Point[]
                   {new Point(0,0),
                    new Point(-1,0),
                    new Point(0,1),
                    new Point(1,1)};

                default:
                    return null;
            }
        }
        public Brush get_Farbe()
        {
            return Farbe;
        }

        public Point get_Position()
        {
            return currPosition;
        }

        public Point[] get_Figur()
        {
            return Shape;
        }

        public void nachLinks()
        {
            currPosition.X -= 1;
        }

        public void nachRechts()
        {
            currPosition.X += 1;
        }

        public void nachUnten()
        {
            currPosition.Y += 1;
        }

        public void Rotieren()
        {
            if (rotieren)
            {
                for (int i = 0; i < Shape.Length; i++)
                {
                    double x = Shape[i].X;
                    Shape[i].X = Shape[i].Y * -1;
                    Shape[i].Y = x;
                }

            }
        }


    }
}
